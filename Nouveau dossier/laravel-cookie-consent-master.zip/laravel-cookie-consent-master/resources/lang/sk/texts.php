<?php

return [
    'message' => 'Táto stránka používa cookies na vylepšenie vášho užívateľského zážitku.',
    'agree' => 'Súhlasím',
];
