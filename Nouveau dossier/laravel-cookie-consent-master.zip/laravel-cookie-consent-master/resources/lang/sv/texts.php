<?php

return [
    'message' => 'Vi använder kakor (cookies) för att webbplatsen ska fungera på ett bra sätt för dig. Genom att surfa vidare godkänner du att vi använder kakor.',
    'agree' => 'Jag förstår',
];
