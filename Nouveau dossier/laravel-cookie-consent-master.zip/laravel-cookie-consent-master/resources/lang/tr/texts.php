<?php

return [
    'message' => 'Bu sitedeki deneyiminizi çerezlere izin vererek geliştirebilirsiniz.',
    'agree' => 'Çerezlere izin ver',
];
