<?php

return [
    'message' => 'Sellel veebilehel on kasutusel cookies-failid teie kasutajaliidese parandamiseks.',
    'agree' => 'Sain aru',
];
