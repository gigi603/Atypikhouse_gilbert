<?php

return [
    'message' => 'Your experience on this site will be improved by allowing cookies.',
    'agree' => 'Allow cookies',
];
